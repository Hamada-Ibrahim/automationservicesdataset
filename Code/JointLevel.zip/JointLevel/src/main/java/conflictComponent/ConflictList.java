package conflictComponent;

import java.util.List;

public class ConflictList 
      {
	   List<Integer> conflicts;

	   public List<Integer> getConflicts() 
	         {
		      return conflicts;
	         }

	   public void setConflicts(List<Integer> conflicts) 
	         {
		      this.conflicts = conflicts;
	         }
	   
	   
      }
