package conflictComponent;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class WithService 
      {
	   @SerializedName("ServiceID")
	   @Expose
	   private Integer serviceid;
	   @SerializedName("RID")
	   @Expose
	   private Integer rid;
	   private String del;
	   private String type;
	   
	   
	   public Integer getServiceID() {return serviceid;}
	   public void setServiceID(Integer sID) {this.serviceid = sID;}
	   public Integer getRuleID() {return rid;}
	   public void setRID(Integer r) {this.rid = r;}
	   public String getDelete() {return del;}
	   public void setDelete(String d) {this.del = d;}
	   public void setType(String p) {this.type = p;}
	   public String getType() { return type;}
      }
