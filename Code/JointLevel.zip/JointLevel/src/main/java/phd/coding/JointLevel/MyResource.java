package phd.coding.JointLevel;

import java.io.IOException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.parser.ParseException;
import org.sosy_lab.common.configuration.InvalidConfigurationException;
import org.sosy_lab.java_smt.api.SolverException;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import serviceComponent.Service;
import serviceComponent.ServiceVerification;



/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource 
	  {
	   private ServiceVerification serviceVer = ServiceVerification.getServiceVerification();
	   JsonParser parser = new JsonParser();
	   Gson gson = new Gson();
    
	   //http://localhost:8080/JointLevel/webapi/myresource
	   @GET
	   @Produces(MediaType.TEXT_PLAIN)
	   public String getIt() 
             {
              return "Got it!";
             }
   
	   //curl -H "Content-Type: application/json" -H "Accept: application/json" -XPOST --data "@/mnt/Programs/RVFramework/RVF/Services/service1.json" http://localhost:8080/JointLevel/webapi/myresource/compositeserviceChecking
	   @POST
	   @Path("compositeserviceChecking")
	   @Consumes(MediaType.APPLICATION_JSON)
	   @Produces(MediaType.APPLICATION_JSON)
	   public Response postCompositeService(String ServiceasJSON) 
			           throws ParseException, InvalidConfigurationException, 
			                  SolverException, InterruptedException, IOException, 
			                  java.text.ParseException 
       	     {
		      JsonElement ServiceJson =  parser.parse(ServiceasJSON);
		      Service service = gson.fromJson(ServiceJson, Service.class);
		      JsonObject serviceconflicts = serviceVer.checkJointServices(service);
		      String result = gson.toJson(serviceconflicts);
		      return Response.status(200).entity("\n\n" + result + "\n\n").build(); 
       	     }
}
