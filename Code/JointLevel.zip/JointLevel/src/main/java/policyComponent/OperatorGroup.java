package policyComponent;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OperatorGroup 
      {
	   @SerializedName("deviceGroup")
	   @Expose
	   private List<DeviceGroup> deviceGroup = null;
	   @SerializedName("Operator")
	   @Expose
	   private String operator;
	   @SerializedName("Negation")
	   @Expose
	   private String negation;

	   public List<DeviceGroup> getDeviceGroup() {
		   return deviceGroup;
	   }

	   public String getOperator() {
		   return operator;
	   }

	   public String getNegation() {
		   return negation;
	   }
      }