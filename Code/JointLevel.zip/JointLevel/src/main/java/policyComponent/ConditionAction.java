package policyComponent;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ConditionAction 
      {
       @SerializedName("DeviceName")
       @Expose
       private String deviceName;
       @SerializedName("operation")
       @Expose
       private String operation;
       @SerializedName("value")
       @Expose
       private String value;
       @SerializedName("Min")
       @Expose
       private List<String> min = null;
       @SerializedName("Max")
       @Expose
       private List<String> max = null;
       
       public String getDeviceName() {
    	   return deviceName;
       }

       public String getOperation() {
    	   return operation;
       }
       
       public String getValue() {
    	   return value;
       }
       
       public List<String> getMin() {
    	   return min;
       }

       public List<String> getMax() {
    	   return max;
       }
      }
