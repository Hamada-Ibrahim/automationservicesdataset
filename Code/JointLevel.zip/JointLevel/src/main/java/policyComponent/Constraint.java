package policyComponent;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Constraint 
      {
	   @SerializedName("P")
	   @Expose
	   private Integer p;
       @SerializedName("P_ID")
       @Expose
       private Integer pID;
       @SerializedName("PLoc")
       @Expose
       private String pLoc;
       @SerializedName("operatorGroup")
       @Expose
       private OperatorGroup operatorGroup;
       @SerializedName("DeviceName")
       @Expose
       private String deviceName;
       @SerializedName("Min")
       @Expose
       private List<String> min = null;
       @SerializedName("Max")
       @Expose
       private List<String> max = null;
       @SerializedName("operation")
       @Expose
       private String operation;
       @SerializedName("value")
       @Expose
       private String value;
       @SerializedName("Policy_ID")
       @Expose
       private Integer polID;
       @SerializedName("UserPriority")
	   @Expose
	   private Integer userpriority;
       @SerializedName("conditionGroup")
       @Expose
       private List<ConditionAction> conditionGroup = null;
       @SerializedName("actionGroup")
       @Expose
       private List<ConditionAction> actionGroup = null;

       public Integer getP() {
    	   return p;
       }
       
       public Integer getPID() {
    	   return pID;
       }

       public Integer getPolicy_ID() {
    	   return polID;
       }
       
       public String getPLoc() {
    	   return pLoc;
       }

       public OperatorGroup getOperatorGroup() {
    	   return operatorGroup;
       }

       public String getDeviceName() {
    	   return deviceName;
       }

       public List<String> getMin() {
    	   return min;
       }

       public List<String> getMax() {
    	   return max;
       }

       public String getOperation() {
    	   return operation;
       }	

       public String getValue() {
    	   return value;
       }
       
       public List<ConditionAction> getConditionGroup() {
    	   return conditionGroup;
       }

       public List<ConditionAction> getActionGroup() {
    	   return actionGroup;
       }
       
       public Integer getUserPriority() {return userpriority;}
      }