package policyComponent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.sosy_lab.common.configuration.InvalidConfigurationException;
import org.sosy_lab.java_smt.api.SolverException;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonWriter;

public class PolicyVerification 
      {
	   static PolicyVerification policyVer = new PolicyVerification();
	 
	   Gson gson = new Gson();
	   BufferedReader br = null;
	   JsonWriter jsonWriter = null;
	   JsonParser parser = new JsonParser();
	   JsonObject result;
	   
	   public static PolicyVerification getPolicyVer(){return policyVer;}

	   public int getNumberofPolicies() 
             {
		      File directory = new File("/mnt/Programs/RVFramework/RVF/Policies");
		      String[] fileNames = directory.list();
		      int total = 0;
		      for (int i = 0; i < fileNames.length; i++)
		         if (fileNames[i].contains(".json"))
			       total++;
		      return total;
             }

	   public ArrayList<String> PoliciesAssertions(List<Constraint> constraints) 
	          {
		       ArrayList<String> Asserts = new ArrayList<String>();
	           ArrayList<String> devices = new ArrayList<String>();
	           String Assertion = "", subdevice = "";
	           String device = "", operation = "", devVal="", Minval = "", Maxval = "";
	           for (int i = 0; i < constraints.size(); i++) 
	              {
	        	   Assertion += "(assert ";
	        	   //simple constraint
	        	   if (constraints.get(i).getMin() == null && constraints.get(i).getOperatorGroup() == null && constraints.get(i).getConditionGroup() == null)
	        	     {
	        		  device = getDeviceDefinition(constraints.get(i).getDeviceName());	
	        		  if (!devices.contains(device))
	        			devices.add(device);
	        		  if (!constraints.get(i).getValue().equals("True") && !constraints.get(i).getValue().equals("False") && !isNumeric(constraints.get(i).getValue()) )
	        		    {
	        			 device = getDeviceDefinition(constraints.get(i).getValue());	
	        			 if (!devices.contains(device))
	   				       devices.add(device);
	        		    }
	        		  if (!constraints.get(i).getValue().equals("True") && !constraints.get(i).getValue().equals("False"))
		    	        {
			         	 if (isNumeric(constraints.get(i).getValue()))
			        	   {	
			        	    devVal = constraints.get(i).getValue(); 
			        	    if (constraints.get(i).getValue().contains("-"))
			        	      devVal = "(-"+constraints.get(i).getValue().replace('-', ' ')+")"; 
			        	    if (constraints.get(i).getOperation() != null)
			        	      Assertion +="("+constraints.get(i).getOperation()+ " " +constraints.get(i).getDeviceName().substring(constraints.get(i).getDeviceName().indexOf('_') + 1)+" "+devVal/*constraintList.get(i).getValue()*/+")";
			        	    else
			        	      Assertion +="(= " +constraints.get(i).getDeviceName().substring(constraints.get(i).getDeviceName().indexOf('_') + 1)+" "+devVal/*constraintList.get(i).getValue()*/+")"; 	
			        	   }
			        	 else
			        	   {
			        		devVal = constraints.get(i).getValue().substring(constraints.get(i).getValue().indexOf('_') + 1);
			        		if (constraints.get(i).getOperation() != null)
			        	      Assertion +="("+constraints.get(i).getOperation()+ " " +constraints.get(i).getDeviceName().substring(constraints.get(i).getDeviceName().indexOf('_') + 1)+" "+ devVal +")";
			        		else
			        		  Assertion +="(= "+constraints.get(i).getDeviceName().substring(constraints.get(i).getDeviceName().indexOf('_') + 1)+" "+ devVal +")";		
			        	   }
		    	        }
	        		  else if (constraints.get(i).getValue().equals("True"))
				        Assertion += " " +constraints.get(i).getDeviceName().substring(constraints.get(i).getDeviceName().indexOf('_') + 1)+" ";
	        		  else if (constraints.get(i).getValue().equals("False"))
	        			Assertion +="(not " +constraints.get(i).getDeviceName().substring(constraints.get(i).getDeviceName().indexOf('_') + 1)+" )"; 
	        	     }
	        	   //operator group
	        	   else if (constraints.get(i).getOperatorGroup() != null)
	    	         {
	    		      for (int o=0; o<constraints.get(i).getOperatorGroup().getDeviceGroup().size(); o++)
	    		         {
	    		    	  device = getDeviceDefinition(constraints.get(i).getOperatorGroup().getDeviceGroup().get(o).getDeviceName());	
		        		  if (!devices.contains(device))
		        		    devices.add(device);
	    		         }
	    		      if (constraints.get(i).getOperatorGroup().getNegation() != null)
	    		        Assertion += "(not ";
	    		      if (constraints.get(i).getOperatorGroup().getOperator().equals("&"))
		    	        Assertion += "(and ";
	    		      else if (constraints.get(i).getOperatorGroup().getOperator().equals("|"))
		    	        Assertion += "(or ";
	    		      for (int op=0; op<constraints.get(i).getOperatorGroup().getDeviceGroup().size(); op++)
		    	         {
	    		    	  if (constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue().equals("False"))
	    		    	    subdevice += "(not "+constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getDeviceName().substring(constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getDeviceName().indexOf('_') + 1)+" )";
	    		    	  else if (constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue().equals("True"))
	    		    		subdevice += " "+ constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getDeviceName().substring(constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getDeviceName().indexOf('_') + 1) +" ";
	    		    	  if ((! constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue().equals("False") &&
		    			       ! constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue().equals("True")) &&
	    		    		  ! isNumeric(constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue()))
	    		    	    {
	    		    		 if (constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getOperation() == null) 
	    		    		   operation = "=";
	    		    		 else
	    		    		   operation = constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getOperation(); 
	    		    		 subdevice += "("+operation+" "+constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getDeviceName().substring(constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getDeviceName().indexOf('_') + 1)+" "+constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue().substring(constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue().indexOf('_') + 1)+" )";
	    		    		}
	    		    	  if ((! constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue().equals("False") &&
	    			          ! constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue().equals("True")) &&
	    		    	      isNumeric(constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue()))
	    		    	    {
	    		    		 if (constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue().contains("-"))
	    		        	   devVal = "(-"+constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue().replace('-', ' ')+")";
	    		    		 else
	    		    		   devVal = constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getValue();	 
	    		    		 subdevice += "("+constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getOperation()+" "+constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getDeviceName().substring(constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getDeviceName().indexOf('_') + 1)+" "+devVal+" )";
	    		    	    }
	    		    	  if (constraints.get(i).getOperatorGroup().getDeviceGroup().get(op).getNegative() != null)
	    		    	    Assertion += " (not "+ subdevice +" )";
	    		    	  else
	    		    		Assertion += subdevice;
	    		    	  subdevice = "";
		    	         }
	    		      if (constraints.get(i).getOperatorGroup().getOperator().equals("&") || constraints.get(i).getOperatorGroup().getOperator().equals("|"))
	    		        Assertion += " )";
	    		      if (constraints.get(i).getOperatorGroup().getNegation() != null)
	    		        Assertion += " )";
	    	         }
	        	   //min max
	        	   else if (constraints.get(i).getMax() != null)
	    	         {
	        		  device = getDeviceDefinition(constraints.get(i).getDeviceName());
	        		  Minval = constraints.get(i).getMin().get(0);
	        	      Maxval = constraints.get(i).getMax().get(0);
	        		  if (!devices.contains(device))
	        		    devices.add(device);
	        		  if (constraints.get(i).getMin().get(0).contains("-"))
	        		    Minval = "(-"+constraints.get(i).getMin().get(0).replace('-', ' ')+")";
	        		  if (constraints.get(i).getMax().get(0).contains("-"))
		        	    Maxval = "(-"+constraints.get(i).getMax().get(0).replace('-', ' ')+")";
	        		  Assertion +="(and ("+ constraints.get(i).getMin().get(1) + " "+ constraints.get(i).getDeviceName().substring(constraints.get(i).getDeviceName().indexOf('_') + 1)+" "+Minval +") "+
	        			  	      "("+ constraints.get(i).getMax().get(1) + " "+ constraints.get(i).getDeviceName().substring(constraints.get(i).getDeviceName().indexOf('_') + 1)+" "+Maxval+") )";
	    	        }
	        	   //ifttt
	        	      //condition may be min max
	        	   else if (constraints.get(i).getActionGroup() != null)
	    	         {
	    		      for (int cond = 0; cond < constraints.get(i).getConditionGroup().size(); cond ++)
	    		         {
	    		    	  device = getDeviceDefinition(constraints.get(i).getConditionGroup().get(cond).getDeviceName());	
		        		  if (!devices.contains(device))
	   				        devices.add(device);
		        		  if (constraints.get(i).getConditionGroup().get(cond).getMax() == null && !isNumeric(constraints.get(i).getConditionGroup().get(cond).getValue()) &&
		        			  !constraints.get(i).getConditionGroup().get(cond).getValue().equals("True") &&
		        			  !constraints.get(i).getConditionGroup().get(cond).getValue().equals("False"))
		        		    {
		        			 device = getDeviceDefinition(constraints.get(i).getConditionGroup().get(cond).getValue());	
			        		 if (!devices.contains(device))
		   				       devices.add(device);  
		        		    } 
	    		         }
	    		      for (int act = 0; act < constraints.get(i).getActionGroup().size(); act ++)
	    		         {
	    		    	  device = getDeviceDefinition(constraints.get(i).getActionGroup().get(act).getDeviceName());	
		        		  if (!devices.contains(device))
	   				        devices.add(device);
		        		  if (!isNumeric(constraints.get(i).getActionGroup().get(act).getValue()) &&
			        		  !constraints.get(i).getActionGroup().get(act).getValue().equals("True") &&
			        		  !constraints.get(i).getActionGroup().get(act).getValue().equals("False"))
		        		    {
		        			 device = getDeviceDefinition(constraints.get(i).getActionGroup().get(act).getValue());	
		        			 if (!devices.contains(device))
		        		       devices.add(device);  
		        		    }
	    		         }
	    		      Assertion +="(=> ";
	    		      if (constraints.get(i).getConditionGroup().size() == 0)
	    		        Assertion += " true ";	 
	    		      else if (constraints.get(i).getConditionGroup().size() > 1)
	    		        Assertion +="(and ";
	    		      for (int cond = 0; cond < constraints.get(i).getConditionGroup().size(); cond ++)
	    		         {
	    		    	  if (constraints.get(i).getConditionGroup().get(cond).getMax() == null)
	    		    	    {
	    			         if (constraints.get(i).getConditionGroup().get(cond).getValue().equals("True") ||
	    			             constraints.get(i).getConditionGroup().get(cond).getValue().equals("False") )
	    			           {
	    				        if (constraints.get(i).getConditionGroup().get(cond).getValue().equals("True"))
	    				          Assertion += " "+constraints.get(i).getConditionGroup().get(cond).getDeviceName().substring(constraints.get(i).getConditionGroup().get(cond).getDeviceName().indexOf('_') + 1)+" ";
	    				        else
	    				          Assertion += "(not "+constraints.get(i).getConditionGroup().get(cond).getDeviceName().substring(constraints.get(i).getConditionGroup().get(cond).getDeviceName().indexOf('_') + 1)+" )";	
	    			           }
	    			         else
	    			           {
	    			            if (isNumeric(constraints.get(i).getConditionGroup().get(cond).getValue()))	
	    			              {
	    			        	   devVal = constraints.get(i).getConditionGroup().get(cond).getValue(); 
	    			               if (constraints.get(i).getConditionGroup().get(cond).getValue().contains("-"))
	    			        	     devVal = "(-"+constraints.get(i).getConditionGroup().get(cond).getValue().replace('-', ' ')+")";	
	    			               Assertion += "("+ constraints.get(i).getConditionGroup().get(cond).getOperation()+ " " +constraints.get(i).getConditionGroup().get(cond).getDeviceName().substring(constraints.get(i).getConditionGroup().get(cond).getDeviceName().indexOf('_') + 1)+ " "+devVal+" )";
	    			              }
	    			            else
	    			        	  {
	    			        	   if (constraints.get(i).getConditionGroup().get(cond).getDeviceName().contains("_B"))
	    			        		 Assertion += "(= "+ constraints.get(i).getConditionGroup().get(cond).getDeviceName().substring(constraints.get(i).getConditionGroup().get(cond).getDeviceName().indexOf('_') + 1)+ " "+ constraints.get(i).getConditionGroup().get(cond).getValue().substring(constraints.get(i).getConditionGroup().get(cond).getValue().indexOf('_') + 1)+" )";
	    			        	   else
	    			        	     Assertion += "("+ constraints.get(i).getConditionGroup().get(cond).getOperation()+ " " +constraints.get(i).getConditionGroup().get(cond).getDeviceName().substring(constraints.get(i).getConditionGroup().get(cond).getDeviceName().indexOf('_') + 1)+ " "+ constraints.get(i).getConditionGroup().get(cond).getValue().substring(constraints.get(i).getConditionGroup().get(cond).getValue().indexOf('_') + 1)+" )"; 
	    			        	  }
	    			           }
	    		    	    }
	    		    	  else
	    		    	    {
	    		    		 Minval = constraints.get(i).getConditionGroup().get(cond).getMin().get(0);
	    	        	     Maxval = constraints.get(i).getConditionGroup().get(cond).getMax().get(0);
	    	        		 if (constraints.get(i).getConditionGroup().get(cond).getMin().get(0).contains("-"))
	    	        		   Minval = "(-"+constraints.get(i).getConditionGroup().get(cond).getMin().get(0).replace('-', ' ')+")";
	    	        		 if (constraints.get(i).getConditionGroup().get(cond).getMax().get(0).contains("-"))
	    		        	   Maxval = "(-"+constraints.get(i).getConditionGroup().get(cond).getMax().get(0).replace('-', ' ')+")"; 
	    	        		 Assertion += "(and ("+constraints.get(i).getConditionGroup().get(cond).getMin().get(1)+ " " +
	    		    					  constraints.get(i).getConditionGroup().get(cond).getDeviceName().substring(constraints.get(i).getConditionGroup().get(cond).getDeviceName().indexOf('_') + 1) + " " +Minval+") ("+
	    		    					  constraints.get(i).getConditionGroup().get(cond).getMax().get(1)+ " " + constraints.get(i).getConditionGroup().get(cond).getDeviceName().substring(constraints.get(i).getConditionGroup().get(cond).getDeviceName().indexOf('_') + 1) + " " +Maxval+"))"; 
	    		    	    }
	    		         }
	    		      if (constraints.get(i).getConditionGroup().size() > 1)
		    	        Assertion +=" )";
	    		      if (constraints.get(i).getActionGroup().size() > 1)
	    		       Assertion +="(and ";
	    		      for (int act = 0; act < constraints.get(i).getActionGroup().size(); act ++)
	    		         {
	    		    	  if (constraints.get(i).getActionGroup().get(act).getMax() == null)
	    		    	    {
		    		         if (constraints.get(i).getActionGroup().get(act).getValue().equals("True") ||
		    			         constraints.get(i).getActionGroup().get(act).getValue().equals("False") )
		    		           {
		    		    	    if (constraints.get(i).getActionGroup().get(act).getValue().equals("True"))
		    			          Assertion += " "+constraints.get(i).getActionGroup().get(act).getDeviceName().substring(constraints.get(i).getActionGroup().get(act).getDeviceName().indexOf('_') + 1)+" ";
		    		    	    else
		    		    	      Assertion += "(not "+constraints.get(i).getActionGroup().get(act).getDeviceName().substring(constraints.get(i).getActionGroup().get(act).getDeviceName().indexOf('_') + 1)+" )";	
		    		           }
		    		         else
		    		           {
		    		           	if (isNumeric(constraints.get(i).getActionGroup().get(act).getValue()))
		    		              {  
		    		               devVal = constraints.get(i).getActionGroup().get(act).getValue(); 
		    		               if (constraints.get(i).getActionGroup().get(act).getValue().contains("-"))
		    		        	     devVal = "(-"+constraints.get(i).getActionGroup().get(act).getValue().replace('-', ' ')+")";
		    		               if (constraints.get(i).getActionGroup().get(act).getOperation() != null)
		    		                 Assertion += "("+ constraints.get(i).getActionGroup().get(act).getOperation()+ " " +constraints.get(i).getActionGroup().get(act).getDeviceName().substring(constraints.get(i).getActionGroup().get(act).getDeviceName().indexOf('_') + 1)+ " "+ devVal+" )";
		    		               else
		    		                 Assertion += "(= " +constraints.get(i).getActionGroup().get(act).getDeviceName().substring(constraints.get(i).getActionGroup().get(act).getDeviceName().indexOf('_') + 1)+ " "+ devVal+" )";
		    		              }
		    		            else
		    		        	  {
		    		               if (constraints.get(i).getActionGroup().get(act).getOperation() == null)	
		    		                 Assertion += "(= " +constraints.get(i).getActionGroup().get(act).getDeviceName().substring(constraints.get(i).getActionGroup().get(act).getDeviceName().indexOf('_') + 1)+ " "+ constraints.get(i).getActionGroup().get(act).getValue().substring(constraints.get(i).getActionGroup().get(act).getValue().indexOf('_') + 1)+" )";
		    		               else
		    		            	 Assertion += "("+constraints.get(i).getActionGroup().get(act).getOperation()+" "+constraints.get(i).getActionGroup().get(act).getDeviceName().substring(constraints.get(i).getActionGroup().get(act).getDeviceName().indexOf('_') + 1)+ " "+ constraints.get(i).getActionGroup().get(act).getValue().substring(constraints.get(i).getActionGroup().get(act).getValue().indexOf('_') + 1)+" )";  
		    		        	  }
		    		           }
	    		    	    }
	    		    	  else
	    		    	    {
	    		    		 Minval = constraints.get(i).getActionGroup().get(act).getMin().get(0);
	    	        	     Maxval = constraints.get(i).getActionGroup().get(act).getMax().get(0);
	    	        		 if (constraints.get(i).getActionGroup().get(act).getMin().get(0).contains("-"))
	    	        		   Minval = "(-"+constraints.get(i).getActionGroup().get(act).getMin().get(0).replace('-', ' ')+")";
	    	        		 if (constraints.get(i).getActionGroup().get(act).getMax().get(0).contains("-"))
	    		        	   Maxval = "(-"+constraints.get(i).getActionGroup().get(act).getMax().get(0).replace('-', ' ')+")"; 
	    		    		 Assertion += "(and ("+constraints.get(i).getActionGroup().get(act).getMin().get(1)+ " " +
	    		    					  constraints.get(i).getActionGroup().get(act).getDeviceName().substring(constraints.get(i).getActionGroup().get(act).getDeviceName().indexOf('_') + 1) + " " + Minval+") ("+
	    		    					  constraints.get(i).getActionGroup().get(act).getMax().get(1)+ " " + constraints.get(i).getActionGroup().get(act).getDeviceName().substring(constraints.get(i).getActionGroup().get(act).getDeviceName().indexOf('_') + 1) + " " + Maxval+"))"; 
	    		    	    }
	    		         }
	    		      if (constraints.get(i).getActionGroup().size() > 1)
			    	    Assertion +=" )";
	    		      Assertion +=" )";
	    	         }
	        	   Assertion += " )";
	        	   String Def = "";
	        	   for (String s : devices)
	        		  Def += s;
	        	   Assertion = Def + Assertion;
	        	   Asserts.add(Assertion);
	        	   Assertion = "";
	        	   devices = new ArrayList<String>();
	              }
		       return Asserts;
	          }
	   
	   public Map <String, List<Integer>> getsharedpoliciesIDs(Integer policyID, List<String> serLocations) throws FileNotFoundException
             {
		      Map <String, List<Integer>> PIDs = new HashMap<String, List<Integer>>();
		      int totPolicies = policyVer.getNumberofPolicies();
		      Policy policy = null;
		      for (int i = 1; i <= totPolicies; i++) 
		         {
		    	  File policyfile = new File("/mnt/Programs/RVFramework/RVF/Policies/policy" + i + ".json");
		    	  if (!policyfile.exists())
		            continue;
		    	  br = new BufferedReader(new FileReader(policyfile));
		    	  policy = gson.fromJson(br, Policy.class);
		    	  List<Integer> IDs = new ArrayList<>();
		    	  boolean flage = false;
		    	  for (int pp = 0; pp < policy.getConstraints().size(); pp++)
		    		 if (policy.getPolicyID() != policyID)
		    		   if ( serLocations.contains(policy.getConstraints().get(pp).getPLoc()))
	                     {
		    			  IDs.add(policy.getConstraints().get(pp).getPID());  
		    			  flage = true;
	                     }
		    	  if (flage == true)
		    		PIDs.put("policy" + i + ".json", IDs); 
		    	  IDs = new ArrayList<>();
		    	  flage = false;
		         }
		      return PIDs;
             }
	   
	   private String getDeviceDefinition(String s)
              {
	       	   String Def = "";
	       	   int len = s.indexOf('_') + 1;
	       	   char type = s.charAt(len);
	       	   String name = s.substring(len);
	       	   if (type == 'B')	
	       		 Def = "(declare-fun " + name + " () Bool) ";
	       	   if (type == 'I')
	       		 Def = "(declare-fun " + name + " () Int) ";
	       	   return Def;
              }
	   
	   public boolean isNumeric(String str){return str.matches("-?\\d+(.\\d+)?");}
      }


