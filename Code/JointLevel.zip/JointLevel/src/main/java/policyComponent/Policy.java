package policyComponent;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Policy 
      {
	   @SerializedName("Policy_ID")
	   @Expose
	   private Integer policyID;
	   @SerializedName("UserID")
	   @Expose
	   private Integer userID;
	   @SerializedName("UserPriority")
	   @Expose
	   private Integer userpriority;
	   @SerializedName("Constraints")
	   @Expose
	   private List<Constraint> constraints;

	   public Integer getPolicyID() {return policyID;}
	   public Integer getUserID() {return userID;}
	   public List<Constraint> getConstraints() {return constraints;}
	   public Integer getUserPriority() {return userpriority;}
	  }