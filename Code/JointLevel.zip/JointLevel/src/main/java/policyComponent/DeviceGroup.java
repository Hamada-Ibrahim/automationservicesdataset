package policyComponent;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DeviceGroup 
      {
	   @SerializedName("DeviceName")
	   @Expose
	   private String deviceName;
	   @SerializedName("operation")
	   @Expose
	   private String operation;
	   @SerializedName("value")
	   @Expose
	   private String value;
	   @SerializedName("negative")
	   @Expose
	   private String negative;

	   public String getDeviceName() {
		   return deviceName;
	   }

	   public String getOperation() {
		   return operation;
	   }

	   public String getValue() {
		   return value;
	   }

	   public String getNegative() {
		   return negative;
	   }
      }