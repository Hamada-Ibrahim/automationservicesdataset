package serviceComponent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class OverlapedService 
      {
	   /* In this Map
	    * string for service file name
	    * ArrayList is for rule IDs
	    */
	   Map <String, ArrayList<Integer>> sharedServicewithIDs = new HashMap<String, ArrayList<Integer>>();

	   public Map<String, ArrayList<Integer>> getSharedServicewithIDs() 
	         {
		      return sharedServicewithIDs;
	         }

	   public void setSharedServicewithIDs(Map<String, ArrayList<Integer>> sharedServicewithIDs) 
	         {
		      this.sharedServicewithIDs = sharedServicewithIDs;
	         }
	   
	   
      }
