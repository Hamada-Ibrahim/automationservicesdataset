package serviceComponent;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Service 
      {
       @SerializedName("ServiceID")
       @Expose
       private Integer serviceID;
       @SerializedName("UserID")
       @Expose
       private Integer userID;
       @SerializedName("UserPriority")
       @Expose
       private Integer userPriority;
       @SerializedName("StartDate")
       @Expose
       private String startDate;
       @SerializedName("Time")
       @Expose
       private String time;
       @SerializedName("Period")
       @Expose
       private Integer period;
       @SerializedName("RepeatEvery")
       @Expose
       private List<String> repeatEvery = null;
       @SerializedName("EndDate")
       @Expose
       private String endDate;
       @SerializedName("Rules")
       @Expose
       private List<Rule> rules = null;

       public Integer getServiceID() {
    	   return serviceID;
       }

       public Integer getUserID() {
    	   return userID;
       }

       public Integer getUserPriority() {
    	   return userPriority;
       }

       public String getStartDate() {
    	   return startDate;
       }

       public String getTime() {
    	   return time;
       }

       public Integer getPeriod() {
    	   return period;
       }

       public List<String> getRepeatEvery() {
    	   return repeatEvery;
       }

       public String getEndDate() {
    	   return endDate;
       }

       public List<Rule> getRules() {
    	   return rules;
       }
      }
