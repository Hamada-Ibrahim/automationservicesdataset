package serviceComponent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.joda.time.DateTime;
import org.joda.time.Interval;
import org.joda.time.LocalTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.simple.parser.ParseException;
import org.sosy_lab.common.configuration.InvalidConfigurationException;
import org.sosy_lab.java_smt.api.SolverException;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonWriter;

import conflictComponent.ConflictList;
import policyComponent.Policy;
import policyComponent.PolicyVerification;

public class ServiceVerification 
      {
	   static ServiceVerification serviceVer = new ServiceVerification();
	   PolicyVerification policyVer = new PolicyVerification();
	   ServiceChecker prover = new ServiceChecker();
	   Gson gson = new Gson();
	   BufferedReader br = null;
	   JsonWriter jsonWriter = null;
	   List<Rule> ruleList = new ArrayList<>();
	   JsonParser parser = new JsonParser();
	   JsonObject result;
	   
	   public static ServiceVerification getServiceVerification(){return serviceVer;}

	   public int getNumberofServices() 
	         {
		      File directory = new File("/mnt/Programs/RVFramework/RVF/Services");
		      String[] fileNames = directory.list();
		      int total = 0;
		      for (int i = 0; i < fileNames.length; i++)
		    	 if (fileNames[i].contains(".json"))
				   total++;
		      return total;
	         }
	   
	   	   private boolean checkOverlapping(Service service, Service single)
	   	      {
		       boolean overlap = false;
		       //Overlapping in Dates
		   	   DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd HH-mm-ss");
		   	   DateTime startDate1 = DateTime.parse(service.getStartDate()+" "+service.getTime(), fmt);
		   	   DateTime endDate1 = DateTime.parse(service.getEndDate()+" "+service.getTime(), fmt);
		   	   DateTime startDate2 = DateTime.parse(single.getStartDate()+" "+single.getTime(), fmt);
		   	   DateTime endDate2 = DateTime.parse(single.getEndDate()+" "+single.getTime(), fmt);
		   	   Interval interval = new Interval( startDate1, endDate1 );
		   	   Interval interval2 = new Interval( startDate2, endDate2 );
		   	   if (interval.overlaps( interval2 ))
	             {
		   		  //Overlapping in Days
	    	      if (!Collections.disjoint(single.getRepeatEvery(), service.getRepeatEvery()))
			        {
	    	    	 //Overlapping in Times 
	    	    	 DateTimeFormatter formatter = DateTimeFormat.forPattern("HH-mm-ss");
	    	    	 LocalTime stime1 = formatter.parseLocalTime(service.getTime());
	    	    	 LocalTime etime1 = stime1.plusMinutes(service.getPeriod());
	    	    	 LocalTime stime2 = formatter.parseLocalTime(single.getTime());
	    	    	 LocalTime etime2 = stime2.plusMinutes(single.getPeriod());
	    	    	 if (( stime1.isBefore( etime2 ) ) && ( stime2.isBefore( etime1 ) ))
				       {
	    	    		 overlap = true; 
				       }
			        }
	             }
		   	   return overlap;
	   	      }
	   
	   public JsonObject checkJointServices(Service service) 
	             	     throws FileNotFoundException, ParseException, InvalidConfigurationException, InterruptedException, SolverException 
	         {
		      JsonObject result = null;
		      List<String> serLocations = new ArrayList<>();
		      ArrayList<String> policies_Strings = null;
		      List<String> compositeIndexesasStrings = new ArrayList<String>();
		      List<String[]> subsets2 = null;
		      List<Integer> correctIDs = null; //contains only shared services with new-added service
		      Map <String, ArrayList<Integer>> sharedServicewithIDs = new HashMap<String, ArrayList<Integer>>();
		      ArrayList<Integer> ids = new ArrayList<>();
		      Service single;
		      boolean bFlag;
		      Map <String, OverlapedService> AllServicesforEachLoc = new HashMap<String, OverlapedService>();
		      Map <ConflictList, List<String>> All = new HashMap<ConflictList, List<String>>();
		      OverlapedService overlaped = null;
		      List<List<String>> Allsers_with_ids = new ArrayList<>();
		      List<String> sers_with_ids = new ArrayList<>();
		      ArrayList<String> assertions = new ArrayList<>();
		      List<List<String>> conflictCombinations = new ArrayList<>();
		      
          
		      for (int r=0; r<service.getRules().size(); r++)
		    	 if (!serLocations.contains(service.getRules().get(r).getRLoc()))
		    	   serLocations.add(service.getRules().get(r).getRLoc());
	      
		      Policy sharedPolicies = saveSharedPolicies(serLocations, service.getServiceID(), false);
		      policies_Strings = policyVer.PoliciesAssertions(sharedPolicies.getConstraints());
	  
		      File directory = new File("/mnt/Programs/RVFramework/RVF/Services");
			  String[] fileNames = directory.list();
			   
		      for (int loc = 0; loc < serLocations.size(); loc++)
		         {
		    	  overlaped = new OverlapedService();
		    	  //get services for each location and save in a map
		    	  for (int i = 0; i < fileNames.length; i++)
		    		 if (fileNames[i].contains(".json"))
				       {
				    	File servicefile = new File("/mnt/Programs/RVFramework/RVF/Services/"+ fileNames[i]);
				    	if (servicefile.exists())
				    	  {
				    	   br = new BufferedReader(new FileReader(servicefile));
			        	   single = gson.fromJson(br, Service.class);
			        	   if (service.getServiceID() != single.getServiceID())
			        	   	 {
			        		  //two services are overlapping in times 
			        		  if (checkOverlapping(service, single))
			        		    for (int r = 0; r < single.getRules().size(); r++)
			        			   if (serLocations.get(loc).equals(single.getRules().get(r).getRLoc()))
			        				 ids.add(single.getRules().get(r).getRID());
			        		  if (ids.size() > 0)
			        		    {
 		        			     sharedServicewithIDs.put(fileNames[i], ids);
			        		     overlaped.setSharedServicewithIDs(sharedServicewithIDs);
			        		    }
			        	   	 }
				    	  }
				    	ids = new ArrayList<>();
				       }
		    	  AllServicesforEachLoc.put(serLocations.get(loc), overlaped);
		    	  sharedServicewithIDs = new HashMap<String, ArrayList<Integer>>();
		         }
		      
		      for (Map.Entry<String, OverlapedService> locservices : AllServicesforEachLoc.entrySet())
		         {
		    	  System.out.println("AllServicesforEachLoc = "+ locservices.getKey());
		    	  OverlapedService sharedService = locservices.getValue();
		    	  Map <String, ArrayList<Integer>> shared = sharedService.getSharedServicewithIDs();
		    	  for (Map.Entry<String, ArrayList<Integer>> services : shared.entrySet())
		    		  {
		    		   System.out.println("services " + services.getKey());
		    		   for (Integer i : services.getValue())
		    			  System.out.println(" i = " + i);
		    		  }
		         }
		      
		      
		      
		      for (Map.Entry<String, OverlapedService> locservices : AllServicesforEachLoc.entrySet())
	    	     for (int r = 0; r < service.getRules().size(); r++)
			        if (service.getRules().get(r).getRLoc().equals(locservices.getKey()))
			          {
			    	   compositeIndexesasStrings.add("service"+service.getServiceID()+".json@"+service.getRules().get(r).getRID()); 
			    	   OverlapedService sharedService = locservices.getValue();
			    	   Map <String, ArrayList<Integer>> shared = sharedService.getSharedServicewithIDs();
			    	   for (Map.Entry<String, ArrayList<Integer>> services : shared.entrySet())
				    	  for (Integer i : services.getValue())
				    	     compositeIndexesasStrings.add(services.getKey() +"@"+i);
			    	   
			    	   
			    	   //System.out.println("compositeIndexesasStrings size = " + compositeIndexesasStrings.size());
			    	   
			    	   //get all combinations
			    	   String[] intArray = new String[compositeIndexesasStrings.size()];
			    	   intArray = compositeIndexesasStrings.toArray(intArray);
				          	
			    	   //System.out.println(compositeIndexesasStrings);
			    	   
			    	   //form combinations of size k = 2, 3, .... intArray.length
			    	   for (int k = 2; k <= intArray.length; k++ )
				    	  {
				    	   subsets2 = new ArrayList<>();
				    	   int[] s = new int[k];
				    	   if (k <= intArray.length) 
				    	     {
				    		  for (int i = 0; (s[i] = i) < k - 1; i++);  
				    		  subsets2.add(getSubset2(intArray, s));
				    		  for (;;) 
				    		     {
				    			  int i;
				    			  for (i = k - 1; i >= 0 && s[i] == intArray.length - k + i; i--); 
				    			  if (i < 0) 
				    				break;
				    			  s[i]++;                 
				    			  for (++i; i < k; i++)   
				    				 s[i] = s[i - 1] + 1; 
				    			  subsets2.add(getSubset2(intArray, s));
				    		     }
				    	     }
				    	   correctIDs = new ArrayList<>();
				    		 
				    	   //get only the indexes of combinations contains the new added service name "service23"
				    	   for (int i = 0; i < subsets2.size(); i++)
				    		  for (int j=0; j<subsets2.get(i).length; j++)
				    			 if (subsets2.get(i)[j].contains("service"+service.getServiceID()))
				    			   correctIDs.add(i);  
				    	        
				    	   //print all combinations
				    	   //System.out.println("Combniations of size k = "+ k);
				    	   for (int id = 0; id < correctIDs.size(); id++)
				    	      {
					    	   for (int j=0; j < subsets2.get(correctIDs.get(id)).length; j++)
						    	  sers_with_ids.add(subsets2.get(correctIDs.get(id))[j]);
						    	    
					    	   //System.out.println("sers_with_ids" + sers_with_ids);
					    	   Allsers_with_ids.add(sers_with_ids);
					    	   sers_with_ids = new ArrayList<>();
				    	      }
					    	 
				    	   bFlag = false;
				    	   //get assertions as strings for each item in Allsers_with_ids
				    	   for (int g = 0; g < Allsers_with_ids.size(); g++)
					    	  {
				    		   //System.out.println("Allsers_with_ids = " + Allsers_with_ids.get(g));
				    		      		   
				    		   assertions = convertActions_forspecificservicerules(Allsers_with_ids.get(g));
					    		 
					    	   for (int conf = 0; conf < conflictCombinations.size(); conf++)
					    	      {
					    		   bFlag = checkIfSubset(Allsers_with_ids.get(g), conflictCombinations.get(conf));
					    		   if (bFlag)
					    			 break;  
					    	      }
					    		 
					    	   //if check return true then do not check contents of Allsers_with_ids.get(g) in next checks
					    	   if (bFlag)
					    		 continue;	
					    		 
					    	   List<Integer> conflicts = prover.detectDynamic_JointBehaviorConflicts2(assertions, policies_Strings);
					    	   
					    	   ConflictList cl = new ConflictList();
					    	   cl.setConflicts(conflicts);
					    	   
					    	   if (conflicts.size() > 0)
					    	     {
					    		  conflictCombinations.add(Allsers_with_ids.get(g));
					    		  All.put(cl, Allsers_with_ids.get(g));
					    		 }
					    	   
					    	   
					    	  }
				    	   Allsers_with_ids = new ArrayList<>();
				    	  }
			    	   compositeIndexesasStrings = new ArrayList<>();
			          }  
		    	  			      
		      for (Map.Entry<ConflictList, List<String>> a : All.entrySet())
	    	     {
		    	  System.out.println("Services " + a.getValue() + " have a conflicts with :");
		    	  ConflictList cl = a.getKey();
		    	  List<Integer> conflicts = cl.getConflicts();
		    	  for (int c = 0; c < conflicts.size(); c++)
		    	     System.out.println(" \t Policy ID = " + sharedPolicies.getConstraints().get(conflicts.get(c)).getPolicy_ID() + " in Constraint ID = " + sharedPolicies.getConstraints().get(conflicts.get(c)).getPID());
		    	 }
		      return result;
	         }
	   
	   private boolean checkIfSubset(List<String> l1, List<String> l2) 
	          {
	           for (Object in : l2) 
	              if (!l1.contains(in)) 
	                return false;
	           return true;
	          }
	   
	   
	   private String[] getSubset2(String[] input, int[] subset) 
              {
		       String[] result = new String[subset.length]; 
		       for (int i = 0; i < subset.length; i++) 
		    	  result[i] = input[subset[i]];
		       return result;
              }
	   
	   
	   private Policy saveSharedPolicies(List<String> serLocations, Integer serviceID, boolean all) throws FileNotFoundException 
	          {
		       int r= 1;
		       Map <String, List<Integer>> PIDs = new HashMap<String, List<Integer>>();
		       
		       if (all == true)
		         PIDs = getSharedPoliciesIDs(serLocations, true);
		       else
		    	 PIDs = getSharedPoliciesIDs(serLocations, false);  
		       
		       try 
                 {
    	          jsonWriter = new JsonWriter(new FileWriter("/mnt/Programs/RVFramework/RVF/Location-based Services/Policies_for_Service("+ serviceID + ").json"));
    	          jsonWriter.setIndent("  ");
    	          jsonWriter.beginObject();
    	          jsonWriter.name("Constraints");
    	          jsonWriter.beginArray();
    	          Policy shpolicy = null;
    	          for (Map.Entry<String, List<Integer>> en : PIDs.entrySet())
    	             {
    	    	      File policyfile = new File("/mnt/Programs/RVFramework/RVF/Policies/"+en.getKey());
    	    	      if (policyfile.exists())
    	    	        {
    	    	    	 br = new BufferedReader(new FileReader(policyfile));
    	    	    	 shpolicy = gson.fromJson(br, Policy.class);
    	    	    	 for (int h = 0; h < shpolicy.getConstraints().size(); h++)
    	    	    		if ( en.getValue().contains(shpolicy.getConstraints().get(h).getPID()))
    		                  {
    	    	    		   jsonWriter.beginObject();
    	    	    		   jsonWriter.name("P");
    	    	    		   jsonWriter.value(r);	
    	    	    		   jsonWriter.name("Policy_ID");
    	    	    		   jsonWriter.value(shpolicy.getPolicyID());
    	    	    		   jsonWriter.name("P_ID");
    	    	    		   jsonWriter.value(shpolicy.getConstraints().get(h).getPID());
    	    	    		   jsonWriter.name("PLoc");
    	    	    		   jsonWriter.value(shpolicy.getConstraints().get(h).getPLoc());
    	    	    		   if (shpolicy.getConstraints().get(h).getOperatorGroup() == null && 
     	    	    	           shpolicy.getConstraints().get(h).getMax() == null &&
     	    	    	           shpolicy.getConstraints().get(h).getConditionGroup() == null)
    	    	    		     {
    	    	    			  jsonWriter.name("DeviceName");
    	    	    			  jsonWriter.value(shpolicy.getConstraints().get(h).getDeviceName());
    	    	    			  if ( isNumeric(shpolicy.getConstraints().get(h).getValue())) 
     	    	    		        {
    	    	    				 jsonWriter.name("operation");
    	    	    				 jsonWriter.value(shpolicy.getConstraints().get(h).getOperation());
     	    	    		        }
    	    	    			  jsonWriter.name("value");
    	    	    			  jsonWriter.value(shpolicy.getConstraints().get(h).getValue());	
    	    	    		     }
    	    	    		   else if (shpolicy.getConstraints().get(h).getActionGroup() != null)
    				             {
    	    	    			  jsonWriter.name("conditionGroup").beginArray();
    	    	    			  for (int cond = 0; cond < shpolicy.getConstraints().get(h).getConditionGroup().size(); cond++) 
						             {
    	    	    				  jsonWriter.beginObject();
    	    	    				  jsonWriter.name("DeviceName");
    	    	    				  jsonWriter.value(shpolicy.getConstraints().get(h).getConditionGroup().get(cond).getDeviceName());
    	    	    				  if (shpolicy.getConstraints().get(h).getConditionGroup().get(cond).getMax() == null)
    					    	        {
    	    	    					 if (!shpolicy.getConstraints().get(h).getConditionGroup().get(cond).getValue().equals("True") &&
    	    	    						 !shpolicy.getConstraints().get(h).getConditionGroup().get(cond).getValue().equals("False"))
    	    	    					   {
    	    	    						jsonWriter.name("operation");
    	    	    						jsonWriter.value(shpolicy.getConstraints().get(h).getConditionGroup().get(cond).getOperation());  
    	    	    					   }
    	    	    					 jsonWriter.name("value");
    	    	    					 jsonWriter.value(shpolicy.getConstraints().get(h).getConditionGroup().get(cond).getValue());
    					    	        }
    	    	    				  else
    					    	        {
    					    	         jsonWriter.name("Min").beginArray().value(shpolicy.getConstraints().get(h).getConditionGroup().get(cond).getMin().get(0)).value(shpolicy.getConstraints().get(h).getConditionGroup().get(cond).getMin().get(1)).endArray();
    					    	         jsonWriter.name("Max").beginArray().value(shpolicy.getConstraints().get(h).getConditionGroup().get(cond).getMax().get(0)).value(shpolicy.getConstraints().get(h).getConditionGroup().get(cond).getMax().get(1)).endArray();
    					    	        }
    	    	    				  jsonWriter.endObject();
						             }
    	    	    			  jsonWriter.endArray();
    	    	    			  jsonWriter.name("actionGroup").beginArray();
    	    	    			  for (int act = 0; act < shpolicy.getConstraints().get(h).getActionGroup().size(); act++) 
						             {
    	    	    				  jsonWriter.beginObject();
    	    	    				  jsonWriter.name("DeviceName");
    	    	    				  jsonWriter.value(shpolicy.getConstraints().get(h).getActionGroup().get(act).getDeviceName());
    	    	    				  if (shpolicy.getConstraints().get(h).getActionGroup().get(act).getMax() == null)
    					    	        {
    	    	    					 if (isNumeric(shpolicy.getConstraints().get(h).getActionGroup().get(act).getValue()))
    	    	    					   {
    	    	    						jsonWriter.name("operation"); 
    	    	    						if (shpolicy.getConstraints().get(h).getActionGroup().get(act).getOperation() == null) 
		    			    	              jsonWriter.value("=");
    	    	    						else
    	    	    						  jsonWriter.value(shpolicy.getConstraints().get(h).getActionGroup().get(act).getOperation());  
    	    	    					   }
    	    	    					 jsonWriter.name("value");
    	    	    					 jsonWriter.value(shpolicy.getConstraints().get(h).getActionGroup().get(act).getValue());
    					    	        }
    	    	    				  else
    	    	    				    {
    	    	    					 jsonWriter.name("Min").beginArray().value(shpolicy.getConstraints().get(h).getActionGroup().get(act).getMin().get(0)).value(shpolicy.getConstraints().get(h).getActionGroup().get(act).getMin().get(1)).endArray();
    	    	    					 jsonWriter.name("Max").beginArray().value(shpolicy.getConstraints().get(h).getActionGroup().get(act).getMax().get(0)).value(shpolicy.getConstraints().get(h).getActionGroup().get(act).getMax().get(1)).endArray();
    	    	    				    }
    	    	    				  jsonWriter.endObject();
						             }
    	    	    			  jsonWriter.endArray();
    				             }
    	    	    		   else if (shpolicy.getConstraints().get(h).getMax() != null)
	   				             {
    	    	    			  jsonWriter.name("DeviceName");
    	    	    			  jsonWriter.value(shpolicy.getConstraints().get(h).getDeviceName());
    	    	    			  if (shpolicy.getConstraints().get(h).getMin() != null) 
    	    	    			    {
    	    	    				 jsonWriter.name("Min").beginArray();
    	    	    				 jsonWriter.value(shpolicy.getConstraints().get(h).getMin().get(0));
    	    	    				 jsonWriter.value(shpolicy.getConstraints().get(h).getMin().get(1));
    	    	    				 jsonWriter.endArray();
    	    	    				 jsonWriter.name("Max").beginArray();
    	    	    				 jsonWriter.value(shpolicy.getConstraints().get(h).getMax().get(0));
    	    	    				 jsonWriter.value(shpolicy.getConstraints().get(h).getMax().get(1));
    	    	    				 jsonWriter.endArray();
    	    	    			    }
	   				             }
    	    	    		   else if (shpolicy.getConstraints().get(h).getOperatorGroup() != null)	
    				             {
    	    	    			  jsonWriter.name("operatorGroup");
    	    	    			  jsonWriter.beginObject();
    	    	    			  jsonWriter.name("deviceGroup").beginArray();
    	    	    			  for (int y=0;y<shpolicy.getConstraints().get(h).getOperatorGroup().getDeviceGroup().size(); y++)
    	    	    			     {
    	    	    				  jsonWriter.beginObject();
    	    	    				  jsonWriter.name("DeviceName");
    	    	    				  jsonWriter.value(shpolicy.getConstraints().get(h).getOperatorGroup().getDeviceGroup().get(y).getDeviceName());
    	    	    				  if (shpolicy.getConstraints().get(h).getOperatorGroup().getDeviceGroup().get(y).getOperation() != null)
    	    	    				    {
    	    	    					 jsonWriter.name("operation");
    	    	    					 jsonWriter.value(shpolicy.getConstraints().get(h).getOperatorGroup().getDeviceGroup().get(y).getOperation());
    	    	    				    }
    	    	    				  jsonWriter.name("value");
    	    	    				  jsonWriter.value(shpolicy.getConstraints().get(h).getOperatorGroup().getDeviceGroup().get(y).getValue());
    	    	    				  if (shpolicy.getConstraints().get(h).getOperatorGroup().getDeviceGroup().get(y).getNegative() != null)
    	    	    				    {
    	    	    					 jsonWriter.name("negative");
    	    	    					 jsonWriter.value(shpolicy.getConstraints().get(h).getOperatorGroup().getDeviceGroup().get(y).getNegative());
    	    	    				    }
    	    	    				  jsonWriter.endObject();
    	    	    			     }	
    	    	    			  jsonWriter.endArray();
    	    	    			  jsonWriter.name("Operator");
    	    	    			  jsonWriter.value(shpolicy.getConstraints().get(h).getOperatorGroup().getOperator());
    	    	    			  if (shpolicy.getConstraints().get(h).getOperatorGroup().getNegation() != null)
    	    	    			    {
    	    	    				 jsonWriter.name("Negation");
    	    	    				 jsonWriter.value(shpolicy.getConstraints().get(h).getOperatorGroup().getNegation());
    	    	    			    }
    	    	    			  jsonWriter.endObject();
    				             }
    	    	    		   jsonWriter.endObject();
    	    	    		   r++; 
    		                  }
    	    	        }
    	             }
    	          jsonWriter.endArray();
    	          jsonWriter.endObject();
                 } 
		       catch (IOException e) {} 
		       finally {try {jsonWriter.close();} catch (IOException e) {}}
		       File policyServicefile = null;
		       policyServicefile = new File("/mnt/Programs/RVFramework/RVF/Location-based Services/Policies_for_Service("+ serviceID + ").json");
		       br = new BufferedReader(new FileReader(policyServicefile));
		       Policy service_shared_policies = gson.fromJson(br, Policy.class);
		       if (service_shared_policies.getConstraints().size() == 0)
		    	 return null;
		       else
		         return service_shared_policies;
	          }

	   private Map<String, List<Integer>> getSharedPoliciesIDs(List<String> serLocations, boolean all) throws FileNotFoundException 
	          {
		   	   Map <String, List<Integer>> PoliciesCIDs = new HashMap<String, List<Integer>>();
		   	   List<Integer> IDs = new ArrayList<>();
		   	   Policy shared = null;
		   	   boolean flage = false;
		   	   File directory = new File("/mnt/Programs/RVFramework/RVF/Policies");
		   	   String[] fileNames = directory.list();
		   	   for (int i = 0; i < fileNames.length; i++)
		          if (fileNames[i].contains(".json"))
		            {
		    	     File policyfile = new File("/mnt/Programs/RVFramework/RVF/Policies/"+ fileNames[i]);
		    	     br = new BufferedReader(new FileReader(policyfile));
		    	     shared = gson.fromJson(br, Policy.class);
		    	     if (policyfile.exists())
		    	       {
		    	    	for (int pp = 0; pp < shared.getConstraints().size(); pp++)
		    	    	   {
		    	    		if ( serLocations.contains(shared.getConstraints().get(pp).getPLoc()) && all == false)
				              {
			    		       IDs.add(shared.getConstraints().get(pp).getPID());  
			    		       flage = true;
				              }
		    	    		if (all == true)
			    	          {
			    	    	   IDs.add(shared.getConstraints().get(pp).getPID());  
				    		   flage = true;
			    	          }
		    	    	   }
		    	    	if (flage == true)
		    	    	  PoliciesCIDs.put(fileNames[i], IDs); 
		    	    	IDs = new ArrayList<>();
		    	    	flage = false; 
		    	       }
		            }
		   	   return PoliciesCIDs;
	          }
	   
	   

	
	   
	   private ArrayList<String> convertActions_forspecificservicerules(List<String> serwithIDs) throws FileNotFoundException 
              {
		       //each item in serwithIDs in the form    [service23@1, service22.json@1]
	   	       ArrayList<String> Asserts = new ArrayList<String>();
	   	       ArrayList<String> devices = new ArrayList<String>();
	   	       ArrayList<String> Names = new ArrayList<String>();
	   	       String Assertion = "", device = "";
	   	       String filename;
	   	       int id;
	   	       
	   	       for (int i = 0; i < serwithIDs.size(); i++)
	   	          {
	   	    	   int index = serwithIDs.get(i).indexOf('@');
	   	    	   filename = serwithIDs.get(i).substring(0, index);
	   	    	   id = Integer.parseInt(serwithIDs.get(i).substring(index+1, serwithIDs.get(i).length()));
	   	    	   File servicefile = new File("/mnt/Programs/RVFramework/RVF/Services/"+ filename);
	   	    	   if (servicefile.exists())
		    	     {
		    		  br = new BufferedReader(new FileReader(servicefile));
	        	      Service service = gson.fromJson(br, Service.class);
	        	      
	        	      List<ConditionAction> actionGroup = service.getRules().get(id-1).getActionGroup();
	        	      ConditionAction[] actions = actionGroup.toArray(new ConditionAction[] {});
	        	      if (actions.length > 1)
		   			    Assertion += "(assert (and ";
	        	      else
	        	    	Assertion += "(assert ";   
		   		   	  for (int act = 0; act < actions.length; act ++)
	                     {
				          //boolean
		   			      if (actions[act].getFunction() == null)
		   			        {
		   				     device = getDeviceDefinition(actions[act].getDeviceName());	
		   				     if (!devices.contains(device))
		   				       devices.add(device);
		   				     if (!actions[act].getValue().equals("True") && !actions[act].getValue().equals("False") && !isNumeric(actions[act].getValue()))
		   				       {
		   				    	device = getDeviceDefinition(actions[act].getValue());	
		   				    	if (!devices.contains(device))
		   				          devices.add(device);  
		   				       } 
		   				     if (actions[act].getValue().equals("True"))
		   				       Assertion += " "+getDeviceName(actions[act].getDeviceName())+" ";
		   				     else if (actions[act].getValue().equals("False"))
		   				       Assertion += "(not "+getDeviceName(actions[act].getDeviceName())+" )"; 
		   				     else if (!actions[act].getValue().equals("True") && !actions[act].getValue().equals("False") && !isNumeric(actions[act].getValue()))
		   				       Assertion += "(= "+getDeviceName(actions[act].getDeviceName())+" "+getDeviceName(actions[act].getValue())+")";
		   				     else
		   				       Assertion += "(= "+getDeviceName(actions[act].getDeviceName())+" "+actions[act].getValue()+")";  
		   			        }
		   			      //function
		   			      else
		   			        {
		   				     Names.add(actions[act].getFunction().getLHS().get(0));
		   				     Names.add(actions[act].getFunction().getLHS().get(1));
		   				     Names.add(actions[act].getFunction().getRHS().get(0));
		   				     Names.add(actions[act].getFunction().getRHS().get(1));
		   				     Names.remove("");
		   				     List<Object> deDup = Names.stream().distinct().collect(Collectors.toList());
		   				     deDup.remove("");
		   				     for (Object Obj : deDup)
	         		            {
		   				    	 if (isNumeric(Obj.toString()))
		   				    	   continue;
		   				    	 else
		   				    	   {
		   				    		device = getDeviceDefinition(Obj.toString());	
		   				    		if (!devices.contains(device))
		   				    	      devices.add(device); 
		   				    	   }
	         		            }
		   				     Assertion += getFunctionAssertion(actions[act].getFunction());
		   				     Names = new ArrayList<>();    
		   			        }
		   			  	}
		   		   	  if (actions.length > 1)
	    			    Assertion += " ))";
		   		   	  else
		   		   		Assertion += " )";
		   		   	  String Def = "";
		   		   	  for (String s : devices)
	    			     Def += s; 
		   		   	  Assertion = Def + Assertion;
		   		   	  Asserts.add(Assertion);
		   		   	  Assertion = "";
		   		   	  devices = new ArrayList<String>();
		   		   	  Names = new ArrayList<String>();
		    	     }
	   	          }
	   	       return Asserts;
              }
	   
	   
	   String getFunctionAssertion(Function fun)
	          {
		       String left = "", right = "", Minval = "", Maxval = ""; 
		       if (fun.getLHS().get(2).equals(""))
  		         {
		    	  if (!isNumeric(fun.getLHS().get(0)))
  			        {
		    		  left = getDeviceName(fun.getLHS().get(0));
		    		 // System.out.println("asd "+ left);
  			        }
		    	  else
		    	    {
		    		 if (fun.getLHS().get(0).contains("-"))
		    		   left = "(-"+fun.getLHS().get(0).replace('-', ' ')+")";
		    		 else
		    		   left = fun.getLHS().get(0);	
		    	    }
  		         }
		       else
  		         {
		    	  if (!isNumeric(fun.getLHS().get(0)) && !isNumeric(fun.getLHS().get(1)))
		    		{
		    		  left = "("+fun.getLHS().get(2)+" "+ getDeviceName(fun.getLHS().get(0)) + " "+ getDeviceName(fun.getLHS().get(1))+")";
		    		  
		    		}
		    	  else if (isNumeric(fun.getLHS().get(0)) && !isNumeric(fun.getLHS().get(1)))
		    	    {
		    		 if (fun.getLHS().get(0).contains("-"))
	        		   left = "("+fun.getLHS().get(2)+ " (-"+fun.getLHS().get(0).replace('-', ' ')+") "+ getDeviceName(fun.getLHS().get(1))+")";
		    		 else
		    		   left = "("+fun.getLHS().get(2)+" "+ fun.getLHS().get(0) + " "+ getDeviceName(fun.getLHS().get(1))+")"; 
		    	    }
		    	  else if (!isNumeric(fun.getLHS().get(0)) && isNumeric(fun.getLHS().get(1)))
   			        { 
		    		 if (fun.getLHS().get(1).contains("-"))
		    		   left = "("+fun.getLHS().get(2)+" "+getDeviceName(fun.getLHS().get(0)) + " (-"+ fun.getLHS().get(1).replace('-', ' ')+"))";	
		    		 else	
		    		   left = "("+fun.getLHS().get(2)+" "+getDeviceName(fun.getLHS().get(0)) + " " + fun.getLHS().get(1)+")";
   			        }
		    	  else if (isNumeric(fun.getLHS().get(0)) && isNumeric(fun.getLHS().get(1)))
   			   	    {
		    		 if (fun.getLHS().get(1).contains("-"))
		    		   Minval = "(- "+fun.getLHS().get(1).replace('-', ' ')+")";
		    		 else
  				       Minval = fun.getLHS().get(1);	
		    		 if (fun.getLHS().get(0).contains("-"))
		    		   Maxval = "(- "+fun.getLHS().get(0).replace('-', ' ')+")";
		    		 else
  				       Maxval = fun.getLHS().get(0);
		    		 left = "("+fun.getLHS().get(2)+" "+Maxval + " "+ Minval+")";
   			   	    }
  		         }
		       if (fun.getRHS().get(2).equals(""))
		         {
		    	  if (!isNumeric(fun.getRHS().get(0)))
 			        right = getDeviceName(fun.getRHS().get(0));	
		    	  else
 			        {
		    		 if (fun.getRHS().get(0).contains("-"))
     		           right = "(-"+fun.getRHS().get(0).replace('-', ' ')+")";
		    		 else
 				       {
		    			 right = fun.getRHS().get(0);
		    			 
 				       }
		    		 
 			        }
		         }
		       else
 		         {
		    	  if (!isNumeric(fun.getRHS().get(0)) && !isNumeric(fun.getRHS().get(1)))
 			        {
		    		  right = "("+fun.getRHS().get(2)+" "+getDeviceName(fun.getRHS().get(0)) + " " + getDeviceName(fun.getRHS().get(1))+")";
		    		 // System.out.println("I'm here " + right);
 			        }
		    	  else if (isNumeric(fun.getRHS().get(0)) && !isNumeric(fun.getRHS().get(1)))
		    	    {
		    		 if (fun.getRHS().get(0).contains("-"))
	        		   right = "("+fun.getRHS().get(2)+" (-"+fun.getRHS().get(0).replace('-', ' ')+") "+ getDeviceName(fun.getRHS().get(1))+")";
		    		 else
 				       right = "("+ fun.getRHS().get(2) +" "+fun.getRHS().get(0) + " "+ getDeviceName(fun.getRHS().get(1))+")"; 
		    	    }
		    	  else if (!isNumeric(fun.getRHS().get(0)) && isNumeric(fun.getRHS().get(1)))
 			        {
		    		 if (fun.getRHS().get(1).contains("-"))
 				       right = "("+fun.getRHS().get(2)+" "+getDeviceName(fun.getRHS().get(0)) + " (-"+ fun.getRHS().get(1).replace('-', ' ')+"))";	
		    		 else	
 				       right = "("+fun.getRHS().get(2)+" "+getDeviceName(fun.getRHS().get(0)) + " " + fun.getRHS().get(1)+")";
 			        }
		    	  else if (isNumeric(fun.getRHS().get(0)) && isNumeric(fun.getRHS().get(1)))
		    	    {
		    		 if (fun.getRHS().get(1).contains("-"))
 			           Minval = "(-"+fun.getRHS().get(1).replace('-', ' ')+")";
		    		 else
		    		   Minval = fun.getRHS().get(1);	
		    		 if (fun.getRHS().get(0).contains("-"))
 				       Maxval = "(-"+fun.getRHS().get(0).replace('-', ' ')+")";
		    		 else
		    		   Maxval = fun.getRHS().get(0);
		    		 right = "("+fun.getRHS().get(2)+" "+Maxval + " "+ Minval+")";
		    	    }
 		         }
		       return "("+fun.getOperator()+" " +left + " " + right+")";
	          }
	   private String getDeviceDefinition(String s)
              {
		       String Def = "";
		       int len = s.indexOf('_') + 1;
		       char type = s.charAt(len);
		       String name = s.substring(len);
		       if (type == 'B')	
	             Def = "(declare-fun " + name + " () Bool) ";
		       if (type == 'I')
	    	     Def = "(declare-fun " + name + " () Int) ";
		       return Def;
              }
	   
	   private String getDeviceName(String device){return device.substring(device.indexOf('_') + 1);}
	   
	   public boolean isNumeric(String str){return str.matches("-?\\d+(.\\d+)?");}

	
      }
