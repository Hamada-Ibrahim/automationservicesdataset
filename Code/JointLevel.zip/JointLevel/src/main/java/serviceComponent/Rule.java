package serviceComponent;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Rule 
      {
       @SerializedName("ser_ID")
       @Expose
       private Integer serID;
       @SerializedName("R_ID")
       @Expose
       private Integer rID;
       @SerializedName("Priority")
       @Expose
       private Integer priority;
       @SerializedName("RLoc")
       @Expose
       private String rLoc;
       @SerializedName("conditionGroup")
       @Expose
       private List<ConditionAction> conditionGroup;
       @SerializedName("actionGroup")
       @Expose
       private List<ConditionAction> actionGroup;
       @SerializedName("UserPriority")
       @Expose
       private Integer userPriority;

       public Integer getSerID() {
    	   return serID;
       }

       public Integer getRID() {
    	   return rID;
       }

       public Integer getPriority() {
    	   return priority;
       }

       public String getRLoc() {
    	   return rLoc;
       }

       public List<ConditionAction> getConditionGroup() {
    	   return conditionGroup;
       }

       public List<ConditionAction> getActionGroup() {
    	   return actionGroup;
       }
       
       public Integer getUserPriority() {
    	   return userPriority;
       }
      }
