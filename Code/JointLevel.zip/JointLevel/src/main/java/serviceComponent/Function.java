package serviceComponent;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Function 
      {
       @SerializedName("LHS")
       @Expose
       private List<String> lHS = null;
       @SerializedName("RHS")
       @Expose
       private List<String> rHS = null;
       @SerializedName("operator")
       @Expose
       private String operator;

       public List<String> getLHS() {
    	   return lHS;
       }
       
       public List<String> getRHS() {
    	   return rHS;
       }	

       public String getOperator() {
    	   return operator;
       }
      }