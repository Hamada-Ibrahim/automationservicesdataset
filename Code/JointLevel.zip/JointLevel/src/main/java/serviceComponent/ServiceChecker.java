package serviceComponent;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.List;

import org.sosy_lab.common.ShutdownNotifier;
import org.sosy_lab.common.configuration.Configuration;
import org.sosy_lab.common.configuration.InvalidConfigurationException;
import org.sosy_lab.common.log.BasicLogManager;
import org.sosy_lab.common.log.LogManager;
import org.sosy_lab.java_smt.SolverContextFactory;
import org.sosy_lab.java_smt.SolverContextFactory.Solvers;
import org.sosy_lab.java_smt.api.BooleanFormula;
import org.sosy_lab.java_smt.api.BooleanFormulaManager;
import org.sosy_lab.java_smt.api.IntegerFormulaManager;
import org.sosy_lab.java_smt.api.ProverEnvironment;
import org.sosy_lab.java_smt.api.SolverContext;
import org.sosy_lab.java_smt.api.SolverException;

import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonWriter;

public class ServiceChecker  
      {
	   BooleanFormulaManager bfmgr;
	   SolverContext context;
	   IntegerFormulaManager ifmgr;
	   JsonParser parser = new JsonParser();
	   JsonWriter jsonWriter = null;
	   Gson gson = new Gson();
	   BufferedReader br = null;
	   
	   public ServiceChecker(){}

	   public ServiceChecker(SolverContext solverContext) 
             {
	  	      context = solverContext;
	  	      bfmgr = context.getFormulaManager().getBooleanFormulaManager();
	  	      ifmgr = context.getFormulaManager().getIntegerFormulaManager();
             }
	   
	   public SolverContext setSolverContext() throws InvalidConfigurationException
	         {
		      Configuration config = Configuration.defaultConfiguration();
		      LogManager logger = BasicLogManager.create(config);
		      ShutdownNotifier notifier = ShutdownNotifier.createDummy();
		      Solvers solver = Solvers.SMTINTERPOL;
		      SolverContext solverContext = SolverContextFactory.createSolverContext(config, logger, notifier, solver);
		      return solverContext;
	         }
	   
	   
	   public List<Integer> detectDynamic_JointBehaviorConflicts2(ArrayList<String> assertions, ArrayList<String> policies_Strings) throws InvalidConfigurationException, InterruptedException, SolverException 
	         {
		      List<Integer> test = new ArrayList<>();
		      try (SolverContext solverContext = setSolverContext(); ProverEnvironment prover = solverContext.newProverEnvironment();) 
	             {
	    	      ServiceChecker Sprover = new ServiceChecker(solverContext);
	    	      test = Sprover.getDynamic_JointBehaviorConflicts2(prover, assertions, policies_Strings);
	    	     }	
		      return test;
	         }
	   
	   
	   private List<Integer> getDynamic_JointBehaviorConflicts2(ProverEnvironment prover, ArrayList<String> assertions, ArrayList<String> policies_Strings) throws InterruptedException, SolverException 
	          {
		       List<Integer> conflicts = new ArrayList<>();
		   	   BooleanFormula[] Actions = buildConstraints(assertions);
		   	   BooleanFormula[] Constraints = buildConstraints(policies_Strings);
		   	   
		   	   for (int inv = 0; inv < Constraints.length; inv++)
		   	      {
		   		   for (int a = 0; a < Actions.length; a++)
		   		      prover.push(Actions[a]); 
		   		   
		   		   prover.push(Constraints[inv]);
		   		   
		   		   if (prover.isUnsat())
		   		     {
		   			  for (int a = 0; a < Actions.length; a++)
			   		     prover.pop();
		   			  prover.pop();
		   			  conflicts.add(inv);
		   			 }
		   		   else
		   		     {
		   			  for (int a = 0; a < Actions.length; a++)
			   		     prover.pop();
		   			  prover.pop();
		   		     }
		   	      }
		       return conflicts;
	          }

	   private BooleanFormula[] buildConstraints(ArrayList<String> rulesandpolicies) 
	   		  {
		       List<BooleanFormula> constraints = new ArrayList<>();
		       for (String constraint : rulesandpolicies) 
		    	  constraints.add(context.getFormulaManager().parse(constraint));
		       return constraints.toArray(new BooleanFormula[] {});
	   		  }
      }