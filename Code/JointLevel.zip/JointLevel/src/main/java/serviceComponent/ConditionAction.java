package serviceComponent;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ConditionAction 
      {
       @SerializedName("DeviceName")
       @Expose
       private String deviceName;
       @SerializedName("operation")
       @Expose
       private String operation;
       @SerializedName("value")
       @Expose
       private String value;
       @SerializedName("function")
       @Expose
       private Function function;
       @SerializedName("Min")
       @Expose
       private List<String> min;
       @SerializedName("Max")
       @Expose
       private List<String> max;
       @SerializedName("negative")
       @Expose
       private String neg;
       @SerializedName("After")
       @Expose
       private String after;
       
       public String getDeviceName() {
    	   return deviceName;
       }

       public String getOperation() {
    	   return operation;
       }
       
       public String getValue() {
    	   return value;
       }

       public Function getFunction() {
    	   return function;
       }

       public List<String> getMin() {
    	   return min;
       }

       public List<String> getMax() {
    	   return max;
       }
       
       public String getNegative() {
    	   return neg;
       }
       
       public String getAfter() {
    	   return after;
       }
      }
